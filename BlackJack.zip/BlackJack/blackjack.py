
import random
jatekos_kartyai = []
oszto_kartyai = []

# Játékos lapjai
while len(jatekos_kartyai) != 2:
    jatekos_kartyai.append(random.randint(1, 11))
    if len(jatekos_kartyai) == 2:
        print("A kártyáid összege:", jatekos_kartyai)


# osztó lapjai
while len(oszto_kartyai) != 2:
    oszto_kartyai.append(random.randint(1, 11))
    if len(oszto_kartyai) == 2:
        print("Az osztó kártyáinak összege:", oszto_kartyai[1])
    if len(oszto_kartyai) > 15:
        print("Az osztó kártyáinak összege:", oszto_kartyai[1])
# Osztó kártyáinak számítása
if sum(oszto_kartyai) == 21:
    print("Az osztónak blackjack-je van, ő nyert!")
elif sum(oszto_kartyai) > 21:
    print("Az osztó túlment 21-en! Te nyertél!")

# Játékos kártyáinak számítása:
while sum(jatekos_kartyai) < 21:
    extra_kartya = str(input("Kérsz még lapot, vagy megállsz?  ( ker, stop)"))
    if extra_kartya == "ker":
        jatekos_kartyai.append(random.randint(1, 11))
        print("Ennyinél jársz most: " + str(sum(jatekos_kartyai)) + " Ezekkel a kártyákkal: ", jatekos_kartyai)
    else:
        print("Az osztó kártyáinak összege: " + str(sum(oszto_kartyai)) + " ezekből a kártyákból: ", oszto_kartyai)
        print("Ennyid van jelenleg " + str(sum(jatekos_kartyai)) + " Ezekből a kártyákból ", jatekos_kartyai)
        if sum(oszto_kartyai) > sum(jatekos_kartyai):
            print("Osztó nyert!")
        else:
            print("Te nyertél!!")
            break
if sum(jatekos_kartyai) > 21:
    print("Túlmentél! Az osztó nyert. :( ")
elif sum(jatekos_kartyai) == 21:
    print(" BlackJacked van!! Te nyertél!  ")

print("Köszi hogy játszottál!")

# Készítették:  Repka András és Pantl Alex Balázs
#Kért jegy: 3